if onServer() then
  function initialize()
      terminate()
  end
end
